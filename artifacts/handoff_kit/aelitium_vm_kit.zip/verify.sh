#!/usr/bin/env bash
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYZ="$HERE/aelitium-verify.pyz"

if [[ "${1:-}" == "--trust-mode" || "${1:-}" == "--strict" || "${1:-}" == "--keys-json" ]]; then
  echo "ERROR: vm_kit verify.sh is embedded-only. For strict mode, run aelitium-verify directly with external keyring." >&2
  exit 1
fi
if [[ "${1:-}" == -* ]]; then
  echo "ERROR: unknown flag for vm_kit verify.sh: ${1:-}" >&2
  exit 1
fi

EVIDENCE="${1:-$HERE/bundle/evidence_pack.json}"

chmod +x "$PYZ"
if [[ ! -f "$EVIDENCE" ]]; then
  echo "ERROR: evidence pack not found: $EVIDENCE" >&2
  exit 1
fi
python3 "$PYZ" verify --trust-mode embedded "$EVIDENCE"
